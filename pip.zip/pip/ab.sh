cha() {
cd ~
if [ -e .termux ];then
cp ~/T*d/*/.env ~/.termux
else
mkdir .termux
cp ~/T*d/*/.env ~/.termux
fi
}
chs() {
cha
cd ~/.termux
if [ -e .env ];then
cd ~/Termux-Ultroid/*
msg My ultroid-Bot starting
msg copy this $PREFIX/bin
bash startup
else
wget -q -O s.py https://gist.githubusercontent.com/rooted-cyber/655a3c12ee1c5d507d031c4be7a91519/raw/ses
python3 s.py
fi
}
cht() {
cd ~
if [ -e Termux-Ultroid ];then
chs
else
msg install ultroid
exit
fi
}
cht